<?php
load_theme_textdomain( 'photography', get_template_directory().'/languages' );
?>